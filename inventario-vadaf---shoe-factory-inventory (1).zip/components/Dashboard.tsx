import React, { useState } from 'react';
import { User, Product, Supplier, Movement } from '../types';
import ProductList from './ProductList';
import SupplierList from './SupplierList';
import MovementLog from './MovementLog';
import Reports from './Reports';
import Settings from './Settings';
import DataManagement from './DataManagement';
import { BoxIcon, TruckIcon, ListIcon, BarChartIcon, SettingsIcon, LogOutIcon, DatabaseIcon } from './Icons';
import { ThemeName } from '../constants';

export type View = 'dashboard' | 'products' | 'suppliers' | 'movements' | 'data' | 'settings';

const NavItem: React.FC<{ icon: React.ReactNode; label: string; isActive: boolean; onClick: () => void; }> = ({ icon, label, isActive, onClick }) => (
    <button onClick={onClick} className={`flex items-center w-full px-4 py-3 text-left transition-colors duration-200 ${isActive ? 'bg-gray-200 text-gray-900' : 'text-gray-600 hover:bg-gray-100'}`}>
        <span className="mr-3">{icon}</span>
        {label}
    </button>
);

export interface ExportOptions {
    products: boolean;
    suppliers: boolean;
    movements: boolean;
    users: boolean;
}

interface DashboardProps {
    user: User;
    products: Product[];
    suppliers: Supplier[];
    movements: Movement[];
    theme: any;
    themeName: ThemeName;
    setThemeName: (theme: ThemeName) => void;
    onAddProduct: (product: Omit<Product, 'id'>) => void;
    onUpdateProduct: (product: Product) => void;
    onDeleteProduct: (productId: string) => void;
    onAddSupplier: (supplier: Omit<Supplier, 'id'>) => void;
    onUpdateSupplier: (supplier: Supplier) => void;
    onDeleteSupplier: (supplierId: string) => void;
    onLogout: () => void;
    onUpdateUser: (userId: string, data: Partial<Pick<User, 'name' | 'password'>>) => void;
    onExportData: (options: ExportOptions) => void;
    onAddMovement: (movementData: Omit<Movement, 'id' | 'date' | 'userId'>) => void;
}

const Dashboard: React.FC<DashboardProps> = (props) => {
    const [currentView, setCurrentView] = useState<View>('dashboard');
    
    const renderView = () => {
        switch (currentView) {
            case 'dashboard':
                return <Reports products={props.products} suppliers={props.suppliers} movements={props.movements} theme={props.theme} onNavigate={setCurrentView} />;
            case 'products':
                return <ProductList products={props.products} suppliers={props.suppliers} user={props.user} onAddProduct={props.onAddProduct} onUpdateProduct={props.onUpdateProduct} onDeleteProduct={props.onDeleteProduct} theme={props.theme} />;
            case 'suppliers':
                return <SupplierList suppliers={props.suppliers} user={props.user} onAddSupplier={props.onAddSupplier} onUpdateSupplier={props.onUpdateSupplier} onDeleteSupplier={props.onDeleteSupplier} theme={props.theme} />;
            case 'movements':
                return <MovementLog 
                            movements={props.movements} 
                            products={props.products} 
                            users={[...USERS, props.user]} 
                            onAddMovement={props.onAddMovement}
                            user={props.user}
                            theme={props.theme}
                        />;
            case 'data':
                return <DataManagement onExportData={props.onExportData} />;
            case 'settings':
                return <Settings 
                            user={props.user}
                            theme={props.themeName} 
                            setTheme={props.setThemeName} 
                            onUpdateUser={props.onUpdateUser}
                        />;
            default:
                return <Reports products={props.products} suppliers={props.suppliers} movements={props.movements} theme={props.theme} onNavigate={setCurrentView} />;
        }
    };
    const USERS = []; // Dummy array to satisfy the prop, full user list is managed in App.tsx
    return (
        <div className={`flex h-screen bg-gray-100 font-sans`}>
            {/* Sidebar */}
            <div className="flex flex-col w-64 bg-white shadow-lg">
                <div className="flex items-center justify-center h-20 border-b">
                    <h1 className={`text-2xl font-bold ${props.theme.text}`}>Inventario VADAF</h1>
                </div>
                <nav className="flex-1 px-2 py-4 space-y-2">
                    <NavItem icon={<BarChartIcon />} label="Dashboard" isActive={currentView === 'dashboard'} onClick={() => setCurrentView('dashboard')} />
                    <NavItem icon={<BoxIcon />} label="Productos" isActive={currentView === 'products'} onClick={() => setCurrentView('products')} />
                    <NavItem icon={<TruckIcon />} label="Proveedores" isActive={currentView === 'suppliers'} onClick={() => setCurrentView('suppliers')} />
                    <NavItem icon={<ListIcon />} label="Movimientos" isActive={currentView === 'movements'} onClick={() => setCurrentView('movements')} />
                    {props.user.role === 'Usuario' && <NavItem icon={<DatabaseIcon />} label="Gestión de Datos" isActive={currentView === 'data'} onClick={() => setCurrentView('data')} />}
                </nav>
                 <div className="px-2 py-4 space-y-2 border-t">
                    <NavItem icon={<SettingsIcon />} label="Configuración" isActive={currentView === 'settings'} onClick={() => setCurrentView('settings')} />
                    <NavItem icon={<LogOutIcon />} label={`Cerrar sesión (${props.user.name})`} isActive={false} onClick={props.onLogout} />
                </div>
            </div>

            {/* Main content */}
            <main className="flex-1 p-6 md:p-10 overflow-y-auto">
                {renderView()}
            </main>
        </div>
    );
};

export default Dashboard;
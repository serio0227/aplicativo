import React, { useMemo, useState } from 'react';
import { Product, Supplier, Movement, ProductCategory, MovementType } from '../types';
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { DollarSignIcon, RefreshCwIcon, CalendarIcon, ArchiveIcon, AlertTriangleIcon, InfoIcon } from './Icons';
import { View } from './Dashboard';

interface ReportsProps {
    products: Product[];
    suppliers: Supplier[];
    movements: Movement[];
    theme: any;
    onNavigate: (view: View) => void;
}

interface KpiExplanation {
    title: string;
    definition: string;
    formula: string;
    interpretation: string;
}

const KpiExplanationModal: React.FC<{ explanation: KpiExplanation; onClose: () => void }> = ({ explanation, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
            <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-xl font-semibold text-gray-800">{explanation.title}</h3>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button>
            </div>
            <div className="p-6 space-y-4">
                <div>
                    <h4 className="font-bold text-gray-700">¿Qué es?</h4>
                    <p className="text-gray-600">{explanation.definition}</p>
                </div>
                <div>
                    <h4 className="font-bold text-gray-700">¿Cómo se calcula?</h4>
                    <p className="text-gray-600 font-mono bg-gray-100 p-2 rounded">{explanation.formula}</p>
                </div>
                <div>
                    <h4 className="font-bold text-gray-700">¿Qué significa el resultado?</h4>
                    <p className="text-gray-600">{explanation.interpretation}</p>
                </div>
                <div className="text-right">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
);


const getGaugeColor = (value: number, max: number, reverse: boolean = false) => {
    const percentage = (value / max) * 100;
    if ((!reverse && percentage < 33) || (reverse && percentage > 66)) return 'bg-red-500';
    if ((!reverse && percentage < 66) || (reverse && percentage > 33)) return 'bg-yellow-500';
    return 'bg-green-500';
};

const KPICard: React.FC<{
    title: string;
    value: string;
    icon: React.ReactNode;
    explanation: KpiExplanation;
    onExplain: (explanation: KpiExplanation) => void;
    gaugeValue?: number;
    gaugeMax?: number;
    gaugeUnit?: string;
    reverseColor?: boolean;
}> = ({ title, value, icon, explanation, onExplain, gaugeValue, gaugeMax, gaugeUnit, reverseColor }) => (
    <div className="bg-white p-4 rounded-lg shadow-md flex flex-col justify-between">
        <div>
            <div className="flex justify-between items-start">
                <div className="p-3 rounded-full bg-indigo-100 mr-4">
                   {icon}
                </div>
                <button onClick={() => onExplain(explanation)} className="text-gray-400 hover:text-gray-600">
                    <InfoIcon className="w-5 h-5" />
                </button>
            </div>
            <h3 className="text-sm font-medium text-gray-500 truncate mt-2">{title}</h3>
            <p className="mt-1 text-2xl font-semibold text-gray-900">{value}</p>
        </div>
        {gaugeValue !== undefined && gaugeMax !== undefined && (
            <div className="mt-4">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                        className={`h-2.5 rounded-full ${getGaugeColor(gaugeValue, gaugeMax, reverseColor)}`}
                        style={{ width: `${Math.min((gaugeValue / gaugeMax) * 100, 100)}%` }}
                    ></div>
                </div>
                <div className="text-xs text-right text-gray-500 mt-1">
                    {gaugeValue.toFixed(gaugeUnit === '%' ? 1: 0)}{gaugeUnit} / {gaugeMax}{gaugeUnit}
                </div>
            </div>
        )}
    </div>
);

const ProductSearch: React.FC<{ products: Product[] }> = ({ products }) => {
    const [selectedProductId, setSelectedProductId] = useState<string>('');
    
    const selectedProduct = useMemo(() => {
        return products.find(p => p.id === selectedProductId);
    }, [selectedProductId, products]);

    const getStatusInfo = (product: Product) => {
        if (product.quantity <= 0) return { text: 'Agotado', color: 'bg-red-200 text-red-800' };
        if (product.quantity <= product.minStock) return { text: 'Bajo Stock', color: 'bg-yellow-200 text-yellow-800' };
        return { text: 'Óptimo', color: 'bg-green-200 text-green-800' };
    };

    return (
        <div className="bg-white p-4 rounded-lg shadow-md">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Búsqueda Rápida de Producto</h2>
            <select 
                value={selectedProductId} 
                onChange={e => setSelectedProductId(e.target.value)}
                className="w-full p-2 border rounded-lg"
            >
                <option value="">-- Seleccione un producto --</option>
                {products.sort((a,b) => a.name.localeCompare(b.name)).map(p => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
            </select>

            {selectedProduct && (
                <div className="mt-4 p-4 border rounded-lg space-y-2">
                    <h3 className="font-bold text-lg text-gray-900">{selectedProduct.name}</h3>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                        <p><strong className="text-gray-500">Código:</strong> {selectedProduct.code}</p>
                        <p><strong className="text-gray-500">Cantidad:</strong> {selectedProduct.quantity}</p>
                        <p><strong className="text-gray-500">Ubicación:</strong> {selectedProduct.location}</p>
                        <p><strong className="text-gray-500">Costo Unit.:</strong> ${selectedProduct.unitCost.toFixed(2)}</p>
                        <p><strong className="text-gray-500">Valor Total:</strong> ${(selectedProduct.quantity * selectedProduct.unitCost).toFixed(2)}</p>
                         <p className="flex items-center"><strong className="text-gray-500 mr-2">Estado:</strong> <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusInfo(selectedProduct).color}`}>{getStatusInfo(selectedProduct).text}</span></p>
                    </div>
                </div>
            )}
        </div>
    );
};

const LowStockModal: React.FC<{ 
    products: Product[]; 
    suppliers: Supplier[]; 
    onClose: () => void;
    onNavigate: (view: View) => void;
    theme: any;
}> = ({ products, suppliers, onClose, onNavigate, theme }) => {
    const supplierMap = useMemo(() => new Map(suppliers.map(s => [s.id, s.name])), [suppliers]);
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center p-4 border-b">
                    <h3 className="text-xl font-semibold text-gray-800">Productos con Stock Bajo</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button>
                </div>
                <div className="p-6">
                    {products.length === 0 ? (
                         <p className="text-gray-600">¡Excelente! No hay productos con stock bajo.</p>
                    ) : (
                        <ul className="space-y-3">
                            {products.map(p => (
                                <li key={p.id} className="p-3 bg-gray-50 rounded-md flex justify-between items-center">
                                    <div>
                                        <p className="font-semibold text-gray-900">{p.name} ({p.code})</p>
                                        <p className="text-sm text-gray-600">
                                            Stock: <span className="font-bold text-red-500">{p.quantity}</span> / Mínimo: {p.minStock}
                                        </p>
                                        <p className="text-xs text-gray-500">Proveedor: {supplierMap.get(p.supplierId) || 'N/A'}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                     <div className="mt-6 text-center">
                        <button onClick={() => onNavigate('movements')} className={`px-6 py-2 text-white rounded-lg shadow ${theme.primaryBg} ${theme.primaryHover}`}>
                           Ir a Registrar Entrada
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};


const STORAGE_RATE = 0.20; // 20% annual storage cost rate

const Reports: React.FC<ReportsProps> = ({ products, suppliers, movements, theme, onNavigate }) => {
    const [isLowStockModalOpen, setIsLowStockModalOpen] = useState(false);
    const [explanationModal, setExplanationModal] = useState<KpiExplanation | null>(null);

    const { totalInventoryValue, inventoryTurnover, daysOfInventory, storageCost, obsolescenceRate, lowStockProducts } = useMemo(() => {
        const totalValue = products.reduce((acc, p) => acc + (p.quantity * p.unitCost), 0);
        
        const costOfGoodsSold = movements
            .filter(m => m.type === MovementType.Outbound)
            .reduce((acc, m) => {
                const product = products.find(p => p.id === m.productId);
                return acc + (m.quantity * (product?.unitCost || 0));
            }, 0);
        
        const turnover = totalValue > 0 ? costOfGoodsSold / totalValue : 0;
        
        const dailyCogs = costOfGoodsSold / 365;
        const dio = dailyCogs > 0 ? totalValue / dailyCogs : 0;

        const estimatedStorageCost = totalValue * STORAGE_RATE;

        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
        const productsWithRecentMovement = new Set(movements.filter(m => new Date(m.date) > ninetyDaysAgo).map(m => m.productId));
        const obsoleteProducts = products.filter(p => !productsWithRecentMovement.has(p.id));
        const obsRate = products.length > 0 ? (obsoleteProducts.length / products.length) * 100 : 0;

        const lowStock = products.filter(p => p.quantity > 0 && p.quantity <= p.minStock);
        
        return {
            totalInventoryValue: totalValue,
            inventoryTurnover: turnover,
            daysOfInventory: dio,
            storageCost: estimatedStorageCost,
            obsolescenceRate: obsRate,
            lowStockProducts: lowStock
        };
    }, [products, movements]);

    const kpiExplanations: Record<string, KpiExplanation> = {
        totalValue: {
            title: "Valor Total del Inventario",
            definition: "Capital total actualmente invertido en todo el stock disponible (materia prima, en proceso y productos terminados).",
            formula: "Suma de (Cantidad de Producto * Costo Unitario) para todos los productos.",
            interpretation: `Tu valor de inventario actual de $${totalInventoryValue.toLocaleString('en-US', {maximumFractionDigits: 0})} representa el capital inmovilizado. Monitorear este valor ayuda a gestionar el flujo de caja y los costos de almacenamiento.`
        },
        turnover: {
            title: "Rotación de Inventario (Anualizada)",
            definition: "Mide cuántas veces la empresa vende y reemplaza su inventario durante un año.",
            formula: "Costo de Bienes Vendidos (COGS) Anual / Valor Actual del Inventario.",
            interpretation: `Un valor de ${inventoryTurnover.toFixed(2)} significa que tu inventario se renueva esa cantidad de veces al año. Un número más alto generalmente indica una gestión eficiente y ventas fuertes. El objetivo ideal suele estar entre 4 y 6.`
        },
        daysOfInventory: {
            title: "Días de Inventario Disponible",
            definition: "El número promedio de días que la empresa tarda en convertir su inventario en ventas.",
            formula: "(Valor del Inventario / COGS Anual) * 365.",
            interpretation: `Actualmente tienes stock para operar durante ${daysOfInventory.toFixed(0)} días. Un número bajo indica eficiencia, pero si es demasiado bajo, corres el riesgo de quedarte sin stock. Un rango saludable suele ser de 30 a 60 días.`
        },
        storageCost: {
            title: "Costo de Almacenamiento (Estimado Anual)",
            definition: "Costo estimado de mantener el inventario en el almacén, incluyendo espacio, seguros y riesgo de obsolescencia.",
            formula: "Valor Total del Inventario * Tasa de Almacenamiento (20%).",
            interpretation: `El costo anual de mantener tu inventario actual se estima en $${storageCost.toLocaleString('en-US', {maximumFractionDigits: 0})}. Reducir el inventario innecesario puede disminuir significativamente este costo oculto.`
        },
        obsolescence: {
            title: "Índice de Obsolescencia",
            definition: "Porcentaje de productos que no han tenido ningún movimiento de salida en los últimos 90 días.",
            formula: "(Nº Productos sin movimiento / Nº Total de Productos) * 100.",
            interpretation: `Un ${obsolescenceRate.toFixed(1)}% de tus productos podría estar volviéndose obsoleto. Un índice alto sugiere un exceso de stock o productos de baja demanda, lo que representa un riesgo financiero. Un objetivo saludable es mantenerlo por debajo del 15%.`
        }
    };

    const categoryData = useMemo(() => {
        const data = Object.values(ProductCategory).map(cat => ({ name: cat, value: 0 }));
        products.forEach(p => {
            const category = data.find(c => c.name === p.category);
            if (category) {
                category.value += 1;
            }
        });
        return data.filter(d => d.value > 0);
    }, [products]);

    const topValueProducts = useMemo(() => {
        return products
            .map(p => ({ name: p.name, value: p.quantity * p.unitCost }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 5);
    }, [products]);

    const VIBRANT_COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF'];
    const axisColor = 'rgb(107 114 128)';
    const tooltipStyles = {
        contentStyle: {
            backgroundColor: '#fff',
            border: `1px solid #ccc'`
        }
    };
    
    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Panel de Indicadores</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                <KPICard title="Valor Total Inventario" value={`$${totalInventoryValue.toLocaleString('en-US', {maximumFractionDigits: 0})}`} icon={<DollarSignIcon className="w-6 h-6 text-indigo-500"/>} explanation={kpiExplanations.totalValue} onExplain={setExplanationModal} />
                <KPICard title="Rotación (Anualizada)" value={inventoryTurnover.toFixed(2)} icon={<RefreshCwIcon className="w-6 h-6 text-indigo-500"/>} explanation={kpiExplanations.turnover} onExplain={setExplanationModal} gaugeValue={inventoryTurnover} gaugeMax={10} gaugeUnit="" />
                <KPICard title="Días de Inventario" value={daysOfInventory.toFixed(0)} icon={<CalendarIcon className="w-6 h-6 text-indigo-500"/>} explanation={kpiExplanations.daysOfInventory} onExplain={setExplanationModal} gaugeValue={daysOfInventory} gaugeMax={120} gaugeUnit=" días" reverseColor />
                <KPICard title="Costo Almacenamiento" value={`$${storageCost.toLocaleString('en-US', {maximumFractionDigits: 0})}`} icon={<ArchiveIcon className="w-6 h-6 text-indigo-500"/>} explanation={kpiExplanations.storageCost} onExplain={setExplanationModal} />
                <KPICard title="Índice Obsolescencia" value={`${obsolescenceRate.toFixed(1)}%`} icon={<AlertTriangleIcon className="w-6 h-6 text-indigo-500"/>} explanation={kpiExplanations.obsolescence} onExplain={setExplanationModal} gaugeValue={obsolescenceRate} gaugeMax={100} gaugeUnit="%" reverseColor />
            </div>
            
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <ProductSearch products={products} />
                </div>
                <button onClick={() => setIsLowStockModalOpen(true)} className="bg-white p-4 rounded-lg shadow-md text-left hover:bg-gray-50 transition-colors">
                     <h2 className="text-lg font-semibold text-gray-800 mb-4">Alertas de Stock Bajo</h2>
                     <p className="text-4xl font-bold text-yellow-500">{lowStockProducts.length}</p>
                     <p className="text-sm text-gray-500">productos necesitan atención</p>
                     <span className="text-xs text-blue-500 mt-2 block">Ver detalles &rarr;</span>
                </button>
             </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded-lg shadow-md">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4">Inventario por Categoría</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie data={categoryData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill={theme.primaryHex} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                                {categoryData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={VIBRANT_COLORS[index % VIBRANT_COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip {...tooltipStyles} formatter={(value, name) => [`${value} productos`, name]} />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
                 <div className="bg-white p-4 rounded-lg shadow-md">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4">Top 5 Productos por Valor</h2>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={topValueProducts} layout="vertical" margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                           <XAxis type="number" stroke={axisColor} />
                           <YAxis dataKey="name" type="category" width={80} stroke={axisColor} tick={{fontSize: 12}} />
                           <Tooltip {...tooltipStyles} cursor={{fill: 'rgba(200,200,200,0.1)'}} formatter={(value: number) => [`$${value.toFixed(2)}`, 'Valor']} />
                           <Legend />
                           <Bar dataKey="value" name="Valor en Stock" fill={theme.primaryHex} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
            {isLowStockModalOpen && (
                <LowStockModal
                    products={lowStockProducts}
                    suppliers={suppliers}
                    onClose={() => setIsLowStockModalOpen(false)}
                    onNavigate={onNavigate}
                    theme={theme}
                />
            )}
            {explanationModal && (
                <KpiExplanationModal explanation={explanationModal} onClose={() => setExplanationModal(null)} />
            )}
        </div>
    );
};

export default Reports;
import React, { useState, useRef } from 'react';
import { THEMES, ThemeName } from '../constants';
import { User } from '../types';

interface SettingsProps {
    user: User;
    theme: ThemeName;
    setTheme: (theme: ThemeName) => void;
    onUpdateUser: (userId: string, data: Partial<Pick<User, 'name' | 'password'>>) => void;
}

const Settings: React.FC<SettingsProps> = ({ user, theme, setTheme, onUpdateUser }) => {
    const [name, setName] = useState(user.name);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

    const handleProfileUpdate = (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);
        if (name !== user.name) {
            onUpdateUser(user.id, { name });
            setMessage({ text: 'Nombre de usuario actualizado con éxito.', type: 'success' });
        }
    };
    
    const handlePasswordChange = (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);
        if (user.password !== currentPassword) {
            setMessage({ text: 'La contraseña actual es incorrecta.', type: 'error' });
            return;
        }
        if (newPassword !== confirmPassword) {
            setMessage({ text: 'Las nuevas contraseñas no coinciden.', type: 'error' });
            return;
        }
        if (newPassword.length < 4) {
             setMessage({ text: 'La nueva contraseña debe tener al menos 4 caracteres.', type: 'error' });
             return;
        }
        onUpdateUser(user.id, { password: newPassword });
        setMessage({ text: 'Contraseña actualizada con éxito.', type: 'success' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
    };

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800">Configuración</h1>
            
            {message && (
                <div className={`p-4 rounded-md text-white ${message.type === 'success' ? 'bg-green-500' : 'bg-red-500'}`}>
                    {message.text}
                </div>
            )}

            {/* Appearance Section */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Apariencia</h2>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Tema de Color</label>
                    <div className="flex space-x-2 mt-2">
                        {Object.keys(THEMES).map(themeName => (
                            <button
                                key={themeName}
                                onClick={() => setTheme(themeName as ThemeName)}
                                className={`w-8 h-8 rounded-full ${THEMES[themeName as ThemeName].primaryBg} border-2 ${theme === themeName ? 'border-gray-900' : 'border-transparent'}`}
                                aria-label={`Select ${themeName} theme`}
                            />
                        ))}
                    </div>
                </div>
            </div>

            {/* Admin-only sections */}
            {user.role === 'Usuario' && (
                <>
                {/* Profile Section */}
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4">Perfil de Usuario</h2>
                    <form onSubmit={handleProfileUpdate} className="space-y-4 mb-6 pb-4 border-b">
                         <div>
                            <label htmlFor="username" className="block text-sm font-medium text-gray-700">Nombre de Usuario</label>
                            <input id="username" type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                         </div>
                         <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Guardar Nombre</button>
                    </form>
                     <form onSubmit={handlePasswordChange} className="space-y-4">
                        <h3 className="font-medium text-gray-800">Cambiar Contraseña</h3>
                         <div>
                            <label htmlFor="currentPassword"  className="block text-sm font-medium text-gray-700">Contraseña Actual</label>
                            <input id="currentPassword" type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                         </div>
                         <div>
                            <label htmlFor="newPassword"  className="block text-sm font-medium text-gray-700">Nueva Contraseña</label>
                            <input id="newPassword" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                         </div>
                         <div>
                            <label htmlFor="confirmPassword"  className="block text-sm font-medium text-gray-700">Confirmar Nueva Contraseña</label>
                            <input id="confirmPassword" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                         </div>
                         <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Cambiar Contraseña</button>
                    </form>
                </div>
                </>
            )}
        </div>
    );
};

export default Settings;
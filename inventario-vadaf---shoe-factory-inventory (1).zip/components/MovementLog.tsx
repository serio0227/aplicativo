import React, { useMemo, useState } from 'react';
import { Movement, Product, User, MovementType } from '../types';

interface MovementLogProps {
    movements: Movement[];
    products: Product[];
    users: User[];
    user: User;
    onAddMovement: (movementData: Omit<Movement, 'id' | 'date' | 'userId'>) => void;
    theme: any;
}

const MovementForm: React.FC<{
    products: Product[];
    onSave: (data: Omit<Movement, 'id' | 'date' | 'userId'>) => void;
    theme: any;
}> = ({ products, onSave, theme }) => {
    const [productId, setProductId] = useState(products[0]?.id || '');
    const [type, setType] = useState<MovementType>(MovementType.Outbound);
    const [quantity, setQuantity] = useState(1);
    const [origin, setOrigin] = useState('');
    const [destination, setDestination] = useState('');
    const [reason, setReason] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!productId || quantity <= 0) {
            alert("Por favor, seleccione un producto y una cantidad válida.");
            return;
        }

        const selectedProduct = products.find(p => p.id === productId);
        if (type === MovementType.Outbound && selectedProduct && quantity > selectedProduct.quantity) {
            alert(`No hay suficiente stock para la salida. Stock actual: ${selectedProduct.quantity}`);
            return;
        }

        onSave({ productId, type, quantity, origin, destination, reason });
        // Reset form
        setQuantity(1);
        setOrigin('');
        setDestination('');
        setReason('');
    };

    return (
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Registrar Nuevo Movimiento</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Producto</label>
                    <select value={productId} onChange={e => setProductId(e.target.value)} className="mt-1 p-2 w-full border rounded">
                        {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Tipo</label>
                    <select value={type} onChange={e => setType(e.target.value as MovementType)} className="mt-1 p-2 w-full border rounded">
                        <option value={MovementType.Outbound}>Salida</option>
                        <option value={MovementType.Inbound}>Entrada</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Cantidad</label>
                    <input type="number" value={quantity} onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} className="mt-1 p-2 w-full border rounded" min="1"/>
                </div>
                {type === MovementType.Inbound && (
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Origen</label>
                        <input type="text" placeholder="Ej: Proveedor A" value={origin} onChange={e => setOrigin(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                    </div>
                )}
                 {type === MovementType.Outbound && (
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Destino</label>
                        <input type="text" placeholder="Ej: Venta Cliente" value={destination} onChange={e => setDestination(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                    </div>
                )}
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Razón/Nota</label>
                    <input type="text" placeholder="Ej: Venta" value={reason} onChange={e => setReason(e.target.value)} className="mt-1 p-2 w-full border rounded" />
                </div>
                <div className="lg:col-start-4">
                    <button type="submit" className={`w-full px-4 py-2 text-white rounded-lg shadow ${theme.primaryBg} ${theme.primaryHover}`}>Registrar</button>
                </div>
            </form>
        </div>
    )
}

const MovementLog: React.FC<MovementLogProps> = ({ movements, products, users, user, onAddMovement, theme }) => {
    const [filter, setFilter] = useState('');

    const enrichedMovements = useMemo(() => {
        // Create a map for quick user lookup
        const userMap = new Map(users.map(u => [u.id, u.name]));
        return movements.map(m => {
            const product = products.find(p => p.id === m.productId);
            return {
                ...m,
                productName: product?.name || 'N/A',
                productCode: product?.code || 'N/A',
                userName: userMap.get(m.userId) || 'N/A',
            };
        }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [movements, products, users]);

    const filteredMovements = useMemo(() => 
        enrichedMovements.filter(m => 
            m.productName.toLowerCase().includes(filter.toLowerCase()) ||
            m.productCode.toLowerCase().includes(filter.toLowerCase()) ||
            m.type.toLowerCase().includes(filter.toLowerCase()) ||
            m.userName.toLowerCase().includes(filter.toLowerCase())
        ), [enrichedMovements, filter]);

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Registro de Movimientos</h1>
            {user.role === 'Usuario' && <MovementForm products={products} onSave={onAddMovement} theme={theme} />}
            <input 
                type="text" 
                placeholder="Buscar por producto, tipo, usuario..."
                value={filter}
                onChange={e => setFilter(e.target.value)}
                className="w-full p-2 border rounded-lg"
            />
            <div className="bg-white p-4 rounded-lg shadow-md overflow-x-auto">
                 <table className="w-full text-left text-sm text-gray-500">
                      <thead className="bg-gray-50 text-xs uppercase text-gray-700">
                          <tr>
                              <th className="px-6 py-3">Fecha</th>
                              <th className="px-6 py-3">Producto</th>
                              <th className="px-6 py-3">Tipo</th>
                              <th className="px-6 py-3">Cantidad</th>
                              <th className="px-6 py-3">Origen</th>
                              <th className="px-6 py-3">Destino</th>
                              <th className="px-6 py-3">Usuario</th>
                              <th className="px-6 py-3">Razón/Nota</th>
                          </tr>
                      </thead>
                      <tbody>
                          {filteredMovements.map(m => (
                              <tr key={m.id} className="bg-white border-b hover:bg-gray-50">
                                  <td className="px-6 py-4">{new Date(m.date).toLocaleString()}</td>
                                  <td className="px-6 py-4 font-medium text-gray-900">{m.productName} ({m.productCode})</td>
                                  <td className="px-6 py-4">
                                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                          m.type === 'Entrada' ? 'bg-green-200 text-green-800' :
                                          m.type === 'Salida' ? 'bg-red-200 text-red-800' :
                                          'bg-yellow-200 text-yellow-800'
                                      }`}>
                                        {m.type}
                                      </span>
                                  </td>
                                  <td className={`px-6 py-4 font-bold ${m.type === 'Entrada' ? 'text-green-600' : 'text-red-600'}`}>
                                    {m.type === 'Entrada' ? '+' : '-'}{m.quantity}
                                  </td>
                                  <td className="px-6 py-4">{m.origin || 'N/A'}</td>
                                  <td className="px-6 py-4">{m.destination || 'N/A'}</td>
                                  <td className="px-6 py-4">{m.userName}</td>
                                  <td className="px-6 py-4">{m.reason}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
            </div>
        </div>
    );
};

export default MovementLog;
import React, { useState } from 'react';
import { ExportOptions } from './Dashboard';

interface DataManagementProps {
    onExportData: (options: ExportOptions) => void;
}

const DataManagement: React.FC<DataManagementProps> = ({ onExportData }) => {
    const [exportOptions, setExportOptions] = useState<ExportOptions>({
        products: true,
        suppliers: true,
        movements: true,
        users: true,
    });

    const handleOptionChange = (option: keyof ExportOptions) => {
        setExportOptions(prev => ({ ...prev, [option]: !prev[option] }));
    };

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800">Gestión de Datos</h1>

            {/* Export Section */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Exportar Datos</h2>
                <p className="text-sm text-gray-600 mb-4">
                    Seleccione las categorías de datos que desea exportar a un archivo JSON de respaldo.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    {Object.keys(exportOptions).map(key => (
                        <div key={key} className="flex items-center">
                             <input
                                type="checkbox"
                                id={`export-${key}`}
                                checked={exportOptions[key as keyof ExportOptions]}
                                onChange={() => handleOptionChange(key as keyof ExportOptions)}
                                className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                            <label htmlFor={`export-${key}`} className="ml-2 block text-sm text-gray-900 capitalize">
                                {key === 'users' ? 'Usuarios' : key === 'products' ? 'Productos' : key === 'suppliers' ? 'Proveedores' : 'Movimientos'}
                            </label>
                        </div>
                    ))}
                </div>
                <button 
                    onClick={() => onExportData(exportOptions)} 
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400"
                    disabled={!Object.values(exportOptions).some(v => v)}
                >
                    Exportar Seleccionado
                </button>
            </div>
        </div>
    );
};

export default DataManagement;
import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
    onLogin: (email: string, pass: string) => User | null;
    theme: any;
}

const Login: React.FC<LoginProps> = ({ onLogin, theme }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        const user = onLogin(email, password);
        if (!user) {
            setError('Credenciales inválidas. Intente de nuevo.');
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="max-w-md w-full bg-white shadow-md rounded-lg p-8">
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Iniciar Sesión</h2>
                <form onSubmit={handleLogin} className="space-y-6">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="mt-1 p-2 w-full border rounded-md"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700">Contraseña</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="mt-1 p-2 w-full border rounded-md"
                            required
                        />
                    </div>
                    {error && <p className="text-red-500 text-sm">{error}</p>}
                    <div>
                        <button type="submit" className={`w-full py-2 px-4 text-white rounded-md ${theme.primaryBg} ${theme.primaryHover}`}>
                            Ingresar
                        </button>
                    </div>
                </form>
                <p className="text-xs text-gray-500 mt-4 text-center">
                    Usuario: admin@example.com (pass: admin)
                </p>
            </div>
        </div>
    );
};

export default Login;
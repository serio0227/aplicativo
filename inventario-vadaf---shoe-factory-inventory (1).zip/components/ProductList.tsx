import React, { useState, useMemo } from 'react';
import { Product, Supplier, User, ProductCategory } from '../types';

const sanitize = (str: string) => str.replace(/</g, "&lt;").replace(/>/g, "&gt;");

const Modal: React.FC<{ children: React.ReactNode; title: string; onClose: () => void; }> = ({ children, title, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button>
            </div>
            <div className="p-6">{children}</div>
        </div>
    </div>
);

const ProductForm: React.FC<{
    product?: Product;
    suppliers: Supplier[];
    onSave: (product: Omit<Product, 'id'> | Product) => void;
    onCancel: () => void;
    theme: any;
}> = ({ product, suppliers, onSave, onCancel, theme }) => {
    const [formData, setFormData] = useState<Omit<Product, 'id'>>(product || {
        code: '', name: '', category: ProductCategory.RawMaterial, quantity: 0, minStock: 10,
        location: '', supplierId: suppliers[0]?.id || '', unitCost: 0, shoeType: '', size: '', color: ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        const isNumber = ['quantity', 'minStock', 'unitCost'].includes(name);
        const textFields = ['name', 'code', 'location', 'shoeType', 'size', 'color'];
        const processedValue = isNumber ? parseFloat(value) : textFields.includes(name) ? sanitize(value) : value;

        setFormData(prev => ({ ...prev, [name]: processedValue }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(product ? { ...formData, id: product.id } : formData);
    };
    
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre del Producto</label>
                    <input id="name" name="name" value={formData.name} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required />
                </div>
                <div>
                    <label htmlFor="code" className="block text-sm font-medium text-gray-700">Código</label>
                    <input id="code" name="code" value={formData.code} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required />
                </div>
                <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700">Categoría</label>
                    <select id="category" name="category" value={formData.category} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required>
                        {Object.values(ProductCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="supplierId" className="block text-sm font-medium text-gray-700">Proveedor</label>
                    <select id="supplierId" name="supplierId" value={formData.supplierId} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required>
                        {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">Cantidad</label>
                    <input id="quantity" type="number" name="quantity" value={formData.quantity} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required min="0"/>
                </div>
                <div>
                    <label htmlFor="minStock" className="block text-sm font-medium text-gray-700">Stock Mínimo</label>
                    <input id="minStock" type="number" name="minStock" value={formData.minStock} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required min="0"/>
                </div>
                <div>
                    <label htmlFor="unitCost" className="block text-sm font-medium text-gray-700">Costo Unitario</label>
                    <input id="unitCost" type="number" name="unitCost" value={formData.unitCost} onChange={handleChange} className="mt-1 p-2 w-full border rounded" required min="0" step="0.01"/>
                </div>
                <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700">Ubicación (Almacén, Fábrica, Bodega)</label>
                    <input id="location" name="location" value={formData.location} onChange={handleChange} className="mt-1 p-2 w-full border rounded" />
                </div>
            </div>
            {formData.category === ProductCategory.FinishedGood && (
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-4 mt-4">
                    <div>
                         <label htmlFor="shoeType" className="block text-sm font-medium text-gray-700">Tipo de Zapato</label>
                         <input id="shoeType" name="shoeType" value={formData.shoeType} onChange={handleChange} className="mt-1 p-2 w-full border rounded" />
                    </div>
                    <div>
                         <label htmlFor="size" className="block text-sm font-medium text-gray-700">Talla</label>
                         <input id="size" name="size" value={formData.size} onChange={handleChange} className="mt-1 p-2 w-full border rounded" />
                    </div>
                    <div>
                         <label htmlFor="color" className="block text-sm font-medium text-gray-700">Color</label>
                         <input id="color" name="color" value={formData.color} onChange={handleChange} className="mt-1 p-2 w-full border rounded" />
                    </div>
                 </div>
            )}
            <div className="flex justify-end space-x-2 pt-4">
                <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400">Cancelar</button>
                <button type="submit" className={`px-4 py-2 text-white rounded-md ${theme.primaryBg} ${theme.primaryHover}`}>Guardar</button>
            </div>
        </form>
    );
};

const ProductList: React.FC<{
    products: Product[];
    suppliers: Supplier[];
    user: User;
    onAddProduct: (product: Omit<Product, 'id'>) => void;
    onUpdateProduct: (product: Product) => void;
    onDeleteProduct: (productId: string) => void;
    theme: any;
}> = ({ products, suppliers, user, onAddProduct, onUpdateProduct, onDeleteProduct, theme }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | undefined>(undefined);
    const [filter, setFilter] = useState('');

    const handleSave = (productData: Omit<Product, 'id'> | Product) => {
        if ('id' in productData) {
            onUpdateProduct(productData);
        } else {
            onAddProduct(productData);
        }
        setIsModalOpen(false);
        setEditingProduct(undefined);
    };

    const openAddModal = () => {
        setEditingProduct(undefined);
        setIsModalOpen(true);
    };

    const openEditModal = (product: Product) => {
        setEditingProduct(product);
        setIsModalOpen(true);
    };

    const filteredProducts = useMemo(() => 
        products.filter(p => 
            p.name.toLowerCase().includes(filter.toLowerCase()) || 
            p.code.toLowerCase().includes(filter.toLowerCase()) ||
            p.category.toLowerCase().includes(filter.toLowerCase())
        ), [products, filter]);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-gray-800">Gestión de Productos</h1>
                {user.role === 'Usuario' && (
                    <button onClick={openAddModal} className={`px-4 py-2 text-white rounded-lg shadow ${theme.primaryBg} ${theme.primaryHover}`}>Añadir Producto</button>
                )}
            </div>
            <input 
                type="text" 
                placeholder="Buscar por nombre, código o categoría..."
                value={filter}
                onChange={e => setFilter(e.target.value)}
                className="w-full p-2 border rounded-lg"
            />
            <div className="bg-white p-4 rounded-lg shadow-md overflow-x-auto">
                 <table className="w-full text-left text-sm text-gray-500">
                      <thead className="bg-gray-50 text-xs uppercase text-gray-700">
                          <tr>
                              <th className="px-6 py-3">Código</th>
                              <th className="px-6 py-3">Nombre</th>
                              <th className="px-6 py-3">Categoría</th>
                              <th className="px-6 py-3">Cantidad</th>
                              <th className="px-6 py-3">Estado</th>
                              <th className="px-6 py-3">Costo Unit.</th>
                              <th className="px-6 py-3">Valor Total</th>
                              {user.role === 'Usuario' && <th className="px-6 py-3">Acciones</th>}
                          </tr>
                      </thead>
                      <tbody>
                          {filteredProducts.map(p => (
                              <tr key={p.id} className="bg-white border-b hover:bg-gray-50">
                                  <td className="px-6 py-4 font-medium text-gray-900">{p.code}</td>
                                  <td className="px-6 py-4">{p.name}</td>
                                  <td className="px-6 py-4">{p.category}</td>
                                  <td className="px-6 py-4 font-bold">{p.quantity}</td>
                                  <td className="px-6 py-4">
                                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                          p.quantity <= 0 ? 'bg-red-200 text-red-800' :
                                          p.quantity <= p.minStock ? 'bg-yellow-200 text-yellow-800' : 
                                          'bg-green-200 text-green-800'
                                      }`}>
                                          {p.quantity <= 0 ? 'Agotado' : p.quantity <= p.minStock ? 'Bajo Stock' : 'Óptimo'}
                                      </span>
                                  </td>
                                  <td className="px-6 py-4">${p.unitCost.toFixed(2)}</td>
                                  <td className="px-6 py-4">${(p.quantity * p.unitCost).toFixed(2)}</td>
                                  {user.role === 'Usuario' && (
                                      <td className="px-6 py-4 flex space-x-2">
                                          <button onClick={() => openEditModal(p)} className="text-blue-500 hover:underline">Editar</button>
                                          <button onClick={() => onDeleteProduct(p.id)} className="text-red-500 hover:underline">Eliminar</button>
                                      </td>
                                  )}
                              </tr>
                          ))}
                      </tbody>
                  </table>
            </div>
            {isModalOpen && (
                <Modal title={editingProduct ? 'Editar Producto' : 'Añadir Producto'} onClose={() => setIsModalOpen(false)}>
                    <ProductForm 
                        product={editingProduct} 
                        suppliers={suppliers} 
                        onSave={handleSave} 
                        onCancel={() => { setIsModalOpen(false); setEditingProduct(undefined); }}
                        theme={theme}
                    />
                </Modal>
            )}
        </div>
    );
};

export default ProductList;
import React, { useState, useMemo } from 'react';
import { Supplier, User } from '../types';

const sanitize = (str: string) => str.replace(/</g, "&lt;").replace(/>/g, "&gt;");

const Modal: React.FC<{ children: React.ReactNode; title: string; onClose: () => void; }> = ({ children, title, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
            <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
                <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button>
            </div>
            <div className="p-6">{children}</div>
        </div>
    </div>
);

const SupplierForm: React.FC<{
    supplier?: Supplier;
    onSave: (supplier: Omit<Supplier, 'id'> | Supplier) => void;
    onCancel: () => void;
    theme: any;
}> = ({ supplier, onSave, onCancel, theme }) => {
    const [formData, setFormData] = useState<Omit<Supplier, 'id'>>(supplier || {
        name: '', nit: '', contact: '', email: '', avgDeliveryTime: 0
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const textFields = ['name', 'nit', 'contact', 'email'];
        const processedValue = name === 'avgDeliveryTime' ? parseInt(value) : textFields.includes(name) ? sanitize(value) : value;

        setFormData(prev => ({ ...prev, [name]: processedValue }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(supplier ? { ...formData, id: supplier.id } : formData);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre del Proveedor</label>
                <input id="name" name="name" value={formData.name} onChange={handleChange} className="mt-1 w-full p-2 border rounded" required />
            </div>
            <div>
                <label htmlFor="nit" className="block text-sm font-medium text-gray-700">NIT</label>
                <input id="nit" name="nit" value={formData.nit} onChange={handleChange} className="mt-1 w-full p-2 border rounded" required />
            </div>
            <div>
                <label htmlFor="contact" className="block text-sm font-medium text-gray-700">Contacto</label>
                <input id="contact" name="contact" value={formData.contact} onChange={handleChange} className="mt-1 w-full p-2 border rounded" />
            </div>
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input id="email" type="email" name="email" value={formData.email} onChange={handleChange} className="mt-1 w-full p-2 border rounded" required />
            </div>
            <div>
                <label htmlFor="avgDeliveryTime" className="block text-sm font-medium text-gray-700">Tiempo de Entrega (días)</label>
                <input id="avgDeliveryTime" type="number" name="avgDeliveryTime" value={formData.avgDeliveryTime} onChange={handleChange} className="mt-1 w-full p-2 border rounded" min="0"/>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
                <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400">Cancelar</button>
                <button type="submit" className={`px-4 py-2 text-white rounded-md ${theme.primaryBg} ${theme.primaryHover}`}>Guardar</button>
            </div>
        </form>
    );
};

const SupplierList: React.FC<{
    suppliers: Supplier[];
    user: User;
    onAddSupplier: (supplier: Omit<Supplier, 'id'>) => void;
    onUpdateSupplier: (supplier: Supplier) => void;
    onDeleteSupplier: (supplierId: string) => void;
    theme: any;
}> = ({ suppliers, user, onAddSupplier, onUpdateSupplier, onDeleteSupplier, theme }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingSupplier, setEditingSupplier] = useState<Supplier | undefined>(undefined);
    const [filter, setFilter] = useState('');

    const handleSave = (supplierData: Omit<Supplier, 'id'> | Supplier) => {
        if ('id' in supplierData) {
            onUpdateSupplier(supplierData);
        } else {
            onAddSupplier(supplierData);
        }
        setIsModalOpen(false);
        setEditingSupplier(undefined);
    };

    const openAddModal = () => {
        setEditingSupplier(undefined);
        setIsModalOpen(true);
    };

    const openEditModal = (supplier: Supplier) => {
        setEditingSupplier(supplier);
        setIsModalOpen(true);
    };

    const filteredSuppliers = useMemo(() => 
        suppliers.filter(s => 
            s.name.toLowerCase().includes(filter.toLowerCase()) || 
            s.nit.toLowerCase().includes(filter.toLowerCase()) ||
            s.contact.toLowerCase().includes(filter.toLowerCase())
        ), [suppliers, filter]);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-gray-800">Gestión de Proveedores</h1>
                {user.role === 'Usuario' && (
                    <button onClick={openAddModal} className={`px-4 py-2 text-white rounded-lg shadow ${theme.primaryBg} ${theme.primaryHover}`}>Añadir Proveedor</button>
                )}
            </div>
             <input 
                type="text" 
                placeholder="Buscar por nombre, NIT o contacto..."
                value={filter}
                onChange={e => setFilter(e.target.value)}
                className="w-full p-2 border rounded-lg"
            />
            <div className="bg-white p-4 rounded-lg shadow-md overflow-x-auto">
                 <table className="w-full text-left text-sm text-gray-500">
                      <thead className="bg-gray-50 text-xs uppercase text-gray-700">
                          <tr>
                              <th className="px-6 py-3">Nombre</th>
                              <th className="px-6 py-3">NIT</th>
                              <th className="px-6 py-3">Contacto</th>
                              <th className="px-6 py-3">Email</th>
                              <th className="px-6 py-3">Entrega (días)</th>
                              {user.role === 'Usuario' && <th className="px-6 py-3">Acciones</th>}
                          </tr>
                      </thead>
                      <tbody>
                          {filteredSuppliers.map(s => (
                              <tr key={s.id} className="bg-white border-b hover:bg-gray-50">
                                  <td className="px-6 py-4 font-medium text-gray-900">{s.name}</td>
                                  <td className="px-6 py-4">{s.nit}</td>
                                  <td className="px-6 py-4">{s.contact}</td>
                                  <td className="px-6 py-4">{s.email}</td>
                                  <td className="px-6 py-4">{s.avgDeliveryTime}</td>
                                  {user.role === 'Usuario' && (
                                      <td className="px-6 py-4 flex space-x-2">
                                          <button onClick={() => openEditModal(s)} className="text-blue-500 hover:underline">Editar</button>
                                          <button onClick={() => onDeleteSupplier(s.id)} className="text-red-500 hover:underline">Eliminar</button>
                                      </td>
                                  )}
                              </tr>
                          ))}
                      </tbody>
                  </table>
            </div>
            {isModalOpen && (
                <Modal title={editingSupplier ? 'Editar Proveedor' : 'Añadir Proveedor'} onClose={() => setIsModalOpen(false)}>
                    <SupplierForm 
                        supplier={editingSupplier} 
                        onSave={handleSave} 
                        onCancel={() => { setIsModalOpen(false); setEditingSupplier(undefined); }}
                        theme={theme}
                    />
                </Modal>
            )}
        </div>
    );
};

export default SupplierList;
import React, { useState, useEffect } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import Login from './components/Login';
import Dashboard, { ExportOptions } from './components/Dashboard';
import { Product, Supplier, Movement, User, MovementType } from './types';
import { PRODUCTS, SUPPLIERS, MOVEMENTS, USERS, THEMES, ThemeName } from './constants';

function App() {
    const [currentUser, setCurrentUser] = useLocalStorage<User | null>('currentUser', null);
    const [users, setUsers] = useLocalStorage<User[]>('users', USERS);
    const [products, setProducts] = useLocalStorage<Product[]>('products', PRODUCTS);
    const [suppliers, setSuppliers] = useLocalStorage<Supplier[]>('suppliers', SUPPLIERS);
    const [movements, setMovements] = useLocalStorage<Movement[]>('movements', MOVEMENTS);
    const [themeName, setThemeName] = useLocalStorage<ThemeName>('theme', 'blue');

    const handleLogin = (email: string, pass: string): User | null => {
        const user = users.find(u => u.email === email && u.password === pass);
        if (user) {
            setCurrentUser(user);
            return user;
        }
        return null;
    };

    const handleLogout = () => {
        setCurrentUser(null);
    };

    const handleUpdateUser = (userId: string, data: Partial<Pick<User, 'name' | 'password'>>) => {
        setUsers(prevUsers => prevUsers.map(u => u.id === userId ? { ...u, ...data } : u));
        if (currentUser?.id === userId) {
            setCurrentUser(prev => prev ? { ...prev, ...data } : null);
        }
    };
    
    const handleExportData = (options: ExportOptions) => {
        const dataToExport: any = {};
        if (options.products) dataToExport.products = products;
        if (options.suppliers) dataToExport.suppliers = suppliers;
        if (options.movements) dataToExport.movements = movements;
        if (options.users) dataToExport.users = users;

        const data = JSON.stringify(dataToExport, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `inventario-vadaf-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const addProduct = (product: Omit<Product, 'id'>) => {
        const newProduct = { ...product, id: `prod-${Date.now()}` };
        setProducts(prev => [...prev, newProduct]);
    };

    const updateProduct = (updatedProduct: Product) => {
        setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    };

    const deleteProduct = (productId: string) => {
        setProducts(prev => prev.filter(p => p.id !== productId));
    };

    const addSupplier = (supplier: Omit<Supplier, 'id'>) => {
        const newSupplier = { ...supplier, id: `sup-${Date.now()}` };
        setSuppliers(prev => [...prev, newSupplier]);
    };

    const updateSupplier = (updatedSupplier: Supplier) => {
        setSuppliers(prev => prev.map(s => s.id === updatedSupplier.id ? updatedSupplier : s));
    };

    const deleteSupplier = (supplierId: string) => {
        setSuppliers(prev => prev.filter(s => s.id !== supplierId));
    };

    const handleAddMovement = (movementData: Omit<Movement, 'id' | 'date' | 'userId'>) => {
        if (!currentUser) return;

        const newMovement: Movement = {
            ...movementData,
            id: `mov-${Date.now()}`,
            date: new Date().toISOString(),
            userId: currentUser.id,
        };

        setMovements(prev => [...prev, newMovement]);

        setProducts(prevProducts => prevProducts.map(p => {
            if (p.id === movementData.productId) {
                const newQuantity = movementData.type === MovementType.Inbound
                    ? p.quantity + movementData.quantity
                    : p.quantity - movementData.quantity;
                return { ...p, quantity: Math.max(0, newQuantity) }; // Prevent negative stock
            }
            return p;
        }));
    };
    
    const theme = THEMES[themeName];

    if (!currentUser) {
        return <Login onLogin={handleLogin} theme={theme} />;
    }

    return (
        <Dashboard
            user={currentUser}
            products={products}
            suppliers={suppliers}
            movements={movements}
            theme={theme}
            themeName={themeName}
            setThemeName={setThemeName}
            onAddProduct={addProduct}
            onUpdateProduct={updateProduct}
            onDeleteProduct={deleteProduct}
            onAddSupplier={addSupplier}
            onUpdateSupplier={updateSupplier}
            onDeleteSupplier={deleteSupplier}
            onLogout={handleLogout}
            onUpdateUser={handleUpdateUser}
            onExportData={handleExportData}
            onAddMovement={handleAddMovement}
        />
    );
}

export default App;
// constants.ts
import { Product, Supplier, User, Movement, ProductCategory, MovementType } from './types';

export const USERS: User[] = [
    { id: 'user-1', name: 'Usuario Principal', email: 'admin@example.com', role: 'Usuario', password: 'admin' },
];

export const SUPPLIERS: Supplier[] = [
    { id: 'sup-1', name: 'Proveedor A', nit: '123456789-0', contact: 'Juan Perez', email: 'juan@proveedora.com', avgDeliveryTime: 15 },
    { id: 'sup-2', name: 'Proveedor B', nit: '987654321-0', contact: 'Maria Lopez', email: 'maria@proveedorb.com', avgDeliveryTime: 10 },
];

export const PRODUCTS: Product[] = [
    { id: 'prod-1', name: 'Cuero Negro', code: 'CU-001', category: ProductCategory.RawMaterial, quantity: 100, minStock: 20, location: 'Almacén A', supplierId: 'sup-1', unitCost: 25.50 },
    { id: 'prod-2', name: 'Suela de Goma', code: 'SU-002', category: ProductCategory.RawMaterial, quantity: 200, minStock: 50, location: 'Almacén B', supplierId: 'sup-2', unitCost: 10.00 },
    { id: 'prod-3', name: 'Zapato Casual "Urban"', code: 'ZC-URBAN-42', category: ProductCategory.FinishedGood, quantity: 50, minStock: 10, location: 'Bodega 1', supplierId: 'sup-1', unitCost: 60.00, shoeType: 'Casual', size: '42', color: 'Negro' },
    { id: 'prod-4', name: 'Zapato Casual "Urban"', code: 'ZC-URBAN-43', category: ProductCategory.FinishedGood, quantity: 5, minStock: 10, location: 'Bodega 1', supplierId: 'sup-1', unitCost: 60.00, shoeType: 'Casual', size: '43', color: 'Negro' },
];

export const MOVEMENTS: Movement[] = [
    { id: 'mov-1', productId: 'prod-1', type: MovementType.Inbound, quantity: 50, date: new Date(Date.now() - 20 * 86400000).toISOString(), userId: 'user-1', reason: 'Compra inicial', origin: 'Proveedor A' },
    { id: 'mov-2', productId: 'prod-2', type: MovementType.Inbound, quantity: 100, date: new Date(Date.now() - 15 * 86400000).toISOString(), userId: 'user-1', reason: 'Compra inicial', origin: 'Proveedor B' },
    { id: 'mov-3', productId: 'prod-3', type: MovementType.Outbound, quantity: 10, date: new Date(Date.now() - 5 * 86400000).toISOString(), userId: 'user-1', reason: 'Venta a cliente', destination: 'Cliente Minorista' },
    { id: 'mov-4', productId: 'prod-1', type: MovementType.Outbound, quantity: 20, date: new Date(Date.now() - 10 * 86400000).toISOString(), userId: 'user-1', reason: 'Uso en producción', destination: 'Línea de Producción 1' },
];

export const THEMES = {
    blue: {
        primaryBg: 'bg-blue-600',
        primaryHover: 'hover:bg-blue-700',
        secondaryBg: 'bg-blue-100',
        text: 'text-blue-800',
        primaryHex: '#3B82F6'
    },
    green: {
        primaryBg: 'bg-green-600',
        primaryHover: 'hover:bg-green-700',
        secondaryBg: 'bg-green-100',
        text: 'text-green-800',
        primaryHex: '#16A34A'
    },
    indigo: {
        primaryBg: 'bg-indigo-600',
        primaryHover: 'hover:bg-indigo-700',
        secondaryBg: 'bg-indigo-100',
        text: 'text-indigo-800',
        primaryHex: '#4F46E5'
    }
};

export type ThemeName = keyof typeof THEMES;
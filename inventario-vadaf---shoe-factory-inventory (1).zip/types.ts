// types.ts
export enum ProductCategory {
    RawMaterial = 'Materia Prima',
    FinishedGood = 'Producto Terminado',
    InProcess = 'En Proceso'
}

export interface Product {
    id: string;
    code: string;
    name: string;
    category: ProductCategory;
    quantity: number;
    minStock: number;
    location: string;
    supplierId: string;
    unitCost: number;
    shoeType?: string;
    size?: string;
    color?: string;
}

export interface Supplier {
    id: string;
    name: string;
    nit: string;
    contact: string;
    email: string;
    avgDeliveryTime: number;
}

export type UserRole = 'Usuario';

export interface User {
    id: string;
    name: string;
    role: UserRole;
    email: string; // for login
    password?: string; // Added for authentication
}

export enum MovementType {
    Inbound = 'Entrada',
    Outbound = 'Salida',
    Adjustment = 'Ajuste'
}

export interface Movement {
    id: string;
    productId: string;
    type: MovementType;
    quantity: number;
    date: string; // ISO string
    userId: string;
    reason?: string;
    origin?: string; // e.g., Supplier Name
    destination?: string; // e.g., Customer, Production Line
}